# Default ProGuard rules
