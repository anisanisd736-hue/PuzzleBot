package com.example.puzzlebot

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var startButton: Button
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startButton = findViewById(R.id.startButton)
        statusText = findViewById(R.id.statusText)

        startButton.setOnClickListener {
            if (FloatingOverlayService.isRunning) {
                stopBot()
            } else {
                startBot()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateUi()
    }

    private fun updateUi() {
        if (FloatingOverlayService.isRunning) {
            startButton.text = getString(R.string.stop_bot)
            statusText.text = getString(R.string.status_running)
        } else {
            startButton.text = getString(R.string.start_bot)
            statusText.text = getString(R.string.status_idle)
        }
    }

    private fun startBot() {
        // 1) Check overlay permission
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }

        // 2) Check accessibility service
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, R.string.need_accessibility, Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }

        // 3) Start the floating overlay service
        val serviceIntent = Intent(this, FloatingOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        startButton.text = getString(R.string.stop_bot)
        statusText.text = getString(R.string.status_running)
    }

    private fun stopBot() {
        stopService(Intent(this, FloatingOverlayService::class.java))
        startButton.text = getString(R.string.start_bot)
        statusText.text = getString(R.string.status_idle)
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("${packageName}/${BotAccessibilityService::class.java.name}")
    }
}
