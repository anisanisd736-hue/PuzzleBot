package com.example.puzzlebot

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.random.Random

/**
 * Simple bot logic.
 *
 * Strategy (intentionally simple, no AI / no OpenCV):
 *  - Build a 6x8 grid covering the screen (good default for match-3 boards).
 *  - On each tick, pick a random cell and tap its center.
 *  - Occasionally swipe-style double tap on two adjacent cells (helps with
 *    match-3 swap mechanics on simple games).
 *  - Random delay between actions so it doesn't look mechanical.
 */
class BotEngine(context: Context) {

    private val handler = Handler(Looper.getMainLooper())
    private var running = false

    private val screenW: Int
    private val screenH: Int

    // Grid configuration - simple defaults that work for most match-3 games.
    private val cols = 6
    private val rows = 8
    // Avoid tapping the very top (status bar / score) and bottom (ads / nav).
    private val topMarginRatio = 0.18f
    private val bottomMarginRatio = 0.15f

    init {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        screenW = metrics.widthPixels
        screenH = metrics.heightPixels
    }

    fun start() {
        if (running) return
        running = true
        scheduleNext()
    }

    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun scheduleNext() {
        if (!running) return
        // Random delay 350-900 ms between taps - feels human-ish.
        val delay = Random.nextLong(350L, 900L)
        handler.postDelayed({
            performAction()
            scheduleNext()
        }, delay)
    }

    private fun performAction() {
        val service = BotAccessibilityService.instance ?: return

        val topMargin = screenH * topMarginRatio
        val usableH = screenH * (1f - topMarginRatio - bottomMarginRatio)
        val cellW = screenW.toFloat() / cols
        val cellH = usableH / rows

        val col = Random.nextInt(cols)
        val row = Random.nextInt(rows)

        // Center of the chosen cell, with a small random jitter.
        val jitterX = Random.nextInt(-12, 13).toFloat()
        val jitterY = Random.nextInt(-12, 13).toFloat()
        val x = (col + 0.5f) * cellW + jitterX
        val y = topMargin + (row + 0.5f) * cellH + jitterY

        service.tap(x.coerceIn(0f, screenW - 1f), y.coerceIn(0f, screenH - 1f))

        // 25% of the time, also tap an adjacent cell shortly after - mimics a swap attempt.
        if (Random.nextInt(100) < 25) {
            handler.postDelayed({
                if (!running) return@postDelayed
                val dx = if (Random.nextBoolean()) 1 else -1
                val dy = if (Random.nextBoolean()) 1 else -1
                val col2 = (col + dx).coerceIn(0, cols - 1)
                val row2 = (row + dy).coerceIn(0, rows - 1)
                val x2 = (col2 + 0.5f) * cellW
                val y2 = topMargin + (row2 + 0.5f) * cellH
                BotAccessibilityService.instance?.tap(
                    x2.coerceIn(0f, screenW - 1f),
                    y2.coerceIn(0f, screenH - 1f)
                )
            }, Random.nextLong(120L, 220L))
        }
    }
}
