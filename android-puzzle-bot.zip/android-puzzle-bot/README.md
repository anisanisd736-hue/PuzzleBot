# Puzzle Bot — Simple Android App

A very simple Android app (Kotlin) that helps you tap automatically on simple
offline puzzle games (match-3 / match-tile style).

## What it does

1. You open the app — you see ONE button: **Start Bot**.
2. You press it — the app asks for two permissions the first time:
   - **Display over other apps** (for the floating button)
   - **Accessibility Service** (so it can tap on other apps)
3. A small round floating button labelled **BOT** appears on top of every screen.
4. Open your puzzle game and **tap the floating BOT button** to start auto-tapping.
   Tap it again to stop. You can also drag the button anywhere on the screen.
5. Come back to the app and press **Stop Bot** to remove the floating button.

The bot taps in a smart 6x8 grid pattern (good default for most match-3 boards),
with small random delays and occasional adjacent "swap" taps. No AI, no OpenCV —
keeps everything simple and beginner-friendly.

## How to run it

1. Install **Android Studio** (Hedgehog 2023.1+ or newer).
2. **File → Open** → select this `android-puzzle-bot` folder.
3. Wait for Gradle sync to finish (Android Studio will download the Gradle
   wrapper automatically the first time).
4. Plug in your Android phone with **USB debugging** turned on (or use an
   emulator with API 24+).
5. Click the green **Run ▶** button.
6. The app installs on your phone — open it and follow the on-screen prompts.

## First-run permission flow

- On first **Start Bot** tap, Android opens the **"Display over other apps"**
  settings page. Toggle Puzzle Bot ON, press back.
- Press **Start Bot** again. Android opens **Accessibility settings**. Find
  "Puzzle Bot" in the list, toggle it ON, accept the warning, press back.
- Press **Start Bot** one more time — the floating BOT button appears.

## File layout

```
android-puzzle-bot/
├── settings.gradle
├── build.gradle
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/puzzlebot/
        │   ├── MainActivity.kt           ← single screen, one button
        │   ├── FloatingOverlayService.kt ← floating BOT button
        │   ├── BotAccessibilityService.kt← performs the tap gestures
        │   └── BotEngine.kt              ← grid-tapping logic
        └── res/                          ← layouts, strings, icons
```

## Notes

- Min Android version: 7.0 (API 24).
- Tested target: Android 14 (API 34).
- Use only on offline puzzle games you own. Many online games forbid
  automation in their terms of service.
